  
     <footer class="footer text-center py-2 theme-bg-dark">
		   
            <p class="copyright"><a href="https://youtube.com/FollowAndrew">FollowAndrew</a></p>
              <?php 
		       dynamic_sidebar('footer-1');
		       ?>

		   
	    </footer>
    
    </div>

    <?php
     
       wp_footer();

    ?> 
    
    
    
    

</body>
</html> 
